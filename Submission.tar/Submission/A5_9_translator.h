#ifndef HELPER_H
#define HELPER_H

typedef struct symtab
{
  char *name;
  char *type;
  char *initial_value;
  int size;
  int offset;
  char *nested;

} symboltable;

/* Support for Lazy TAC generation through Quad array */

#define NSYMS 20

typedef struct quad_tag
{
  char *op;
  char *result, *arg1, *arg2;
  char *op_type;
} quad;

quad *qArray[NSYMS]; // Store of Quads
quad *rArray[NSYMS]; // Register Allocation
symboltable symtab[NSYMS];

char *symlook(char *);

union var_value
{
  /* data */
  int int_val;
  char *char_val;
};

char *convert_int_to_string(int);
int convert_string_to_int(char *);

symboltable *sym_update(char *name, char *attr, union var_value new_val);

void printSymbolTable();

// void print_quad(quad *q);

symboltable *symfind(char *);

char *gentemp(char *val, char *type);

quad *new_quad_binary(char *op1, char *s1, char *s2, char *s3);
quad *new_quad_unary(char *op1, char *s1, char *s2);

void print_quad(quad *q, char *mode);

void print_quad_array();

void register_allocation();

int starts_with(const char *pre, const char *str);

void check_quad(quad *q);

#endif
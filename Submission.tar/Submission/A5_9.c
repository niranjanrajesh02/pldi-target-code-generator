#include <stdio.h>
#include "lex.yy.c"
#include "y.tab.h"
#include "y.tab.c"
#include "helper.h"

int main()
{
  yyin = fopen("./A5_9.nc", "r");
  printf("\nGrammar Reductions:\n\n");
  yyparse();
  printf("\nParsing Complete. Goodnight!\n\n");
  printSymbolTable();
  printf("\nQuads:\n");
  print_quad_array();
  printf("\nRegister Allocation:\n");
  register_allocation();
  return 0;
}